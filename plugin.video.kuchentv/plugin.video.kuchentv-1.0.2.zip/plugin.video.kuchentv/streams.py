# -*- coding: utf-8 -*-
#------------------------------------------------------------
# PowerPyx Playlist Loader
# (c) 2019 - ExodusCrowley
# version 1.0.2
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.kuchentv'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
		("--------------------------------------------", "", ''),
        ("[COLOR orange]KuchenTV[/COLOR]--Alle Videos", "playlist/UUr78AIw8O_HGs2jMUAGEp_g", ''),
        ("[COLOR orange]KuchenTV[/COLOR]--Kaffee und Kuchen", "playlist/PL1MouSX81t30flgytJKrzdULw66oXL9fB", ''),
		("[COLOR orange]KuchenTV[/COLOR]--Kuchen Talks 2.0", "playlist/PL1MouSX81t33aH3FV5F5-DKIJP7fT2IoC", ''),
        ("[COLOR orange]KuchenTV[/COLOR]--Cake News", "playlist/PL1MouSX81t33rR2hzxT_uw9IHDatJ2Zp2", ''),
        ("[COLOR orange]KuchenTV[/COLOR]--Kuchen Talks", "playlist/PL1MouSX81t32hznEGtM4gtpqEjsPmlG1s", ''),
        ("--------------------------------------------", "", ''),
        ("[COLOR green]KuchenTV Uncut[/COLOR]--Alle Videos", "playlist/PL1MouSX81t32hznEGtM4gtpqEjsPmlG1s", ''),
        ("--------------------------------------------", "", ''),
        ("[COLOR red]Human Macher[/COLOR]--Alle Videos", "playlist/UU5jIBiFHZF39nGu0sxRLmaA", ''),
        ("[COLOR red]Human Macher[/COLOR]--KuchenTV Talkrunden", "playlist/PLRaOJuqCjvloATKK6xEPDXYZHyufY5YcB", ''),
        ("[COLOR red]Human Macher[/COLOR]--KuchenTV reagiert auf DOKUS/Funk", "playlist/PLRaOJuqCjvlrI5RYfFYXCmiP5VYxx9dzT", ''),
        ("[COLOR red]Human Macher[/COLOR]--KuchenTV TikTok Cringe Reaktionen", "playlist/PLRaOJuqCjvlqZ9j3DdDu5WHltKybkL9jz", ''),
        ("--------------------------------------------", "", ''),
		
		
]



# Entry point
def run():
    plugintools.log("youtubeAddon.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("youtubeAddon.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )



run()
